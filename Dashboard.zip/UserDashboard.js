import { Component }from "react";
    class UserDashboard extends Component
    {
        render(){
            return<h1>Welcome User</h1>
        }
    }
export default UserDashboard;
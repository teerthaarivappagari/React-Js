import { Component }from "react";
    class AdminDashboard extends Component
    {
        render(){
            return<h1>Welcome Admin</h1>
        }
    }
export default AdminDashboard;
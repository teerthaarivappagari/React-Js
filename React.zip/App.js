import logo from './logo.svg';
import './App.css';

function App() {
  return <h1>Welcome to Node JS</h1>
    
}

export default App;
